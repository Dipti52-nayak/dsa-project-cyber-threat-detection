from module4_database.db_connection import create_connection


def generate_report():

    connection = create_connection()
    cursor = connection.cursor()

    query = """
    SELECT * FROM threat_logs
    ORDER BY detected_at DESC
    """

    cursor.execute(query)
    records = cursor.fetchall()

    with open("threat_report.txt", "w") as file:

        file.write("====================================\n")
        file.write("       CYBER THREAT REPORT\n")
        file.write("====================================\n\n")

        file.write("Total Threats: " + str(len(records)) + "\n\n")

        for record in records:

            file.write("------------------------------------\n")
            file.write("Threat ID: " + str(record[0]) + "\n")
            file.write("Source IP: " + record[1] + "\n")
            file.write("Threat Type: " + record[2] + "\n")
            file.write("Threat Level: " + record[3] + "\n")
            file.write("Priority: " + str(record[4]) + "\n")
            file.write("Detected At: " + str(record[5]) + "\n")

        file.write("\n========== REPORT COMPLETED ==========\n")

    print("Threat Report Generated Successfully!")
    print("File Name: threat_report.txt")

    cursor.close()
    connection.close()