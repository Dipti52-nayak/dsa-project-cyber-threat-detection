from module5_alert_reporting.alert_manager import AlertManager

manager = AlertManager()

# Sample threats
threat1 = {
    "source_ip": "192.168.1.50",
    "threat_type": "Multiple Failed Login Attempts",
    "threat_level": "HIGH",
    "priority": 2
}

threat2 = {
    "source_ip": "10.0.0.5",
    "threat_type": "Port Scanning Detected",
    "threat_level": "HIGH",
    "priority": 2
}

# Add alerts
manager.add_alert(threat1)
manager.add_alert(threat2)

# Display all alerts
manager.display_alerts()