from module4_database.db_connection import create_connection


def show_statistics():

    connection = create_connection()
    cursor = connection.cursor()

    # Total threats
    cursor.execute("SELECT COUNT(*) FROM threat_logs")
    total = cursor.fetchone()[0]

    print("\n======= CYBER THREAT STATISTICS =======")

    print("Total Threats:", total)

    # Threats by severity
    cursor.execute("""
        SELECT threat_level, COUNT(*)
        FROM threat_logs
        GROUP BY threat_level
    """)

    results = cursor.fetchall()

    print("\nThreats By Severity:")

    for level, count in results:
        print(level, ":", count)

    # Threats by type
    cursor.execute("""
        SELECT threat_type, COUNT(*)
        FROM threat_logs
        GROUP BY threat_type
    """)

    results = cursor.fetchall()

    print("\nThreats By Type:")

    for threat_type, count in results:
        print(threat_type, ":", count)

    # Most active suspicious IP
    cursor.execute("""
        SELECT source_ip, COUNT(*)
        FROM threat_logs
        GROUP BY source_ip
        ORDER BY COUNT(*) DESC
        LIMIT 1
    """)

    result = cursor.fetchone()

    if result:
        print("\nMost Active Suspicious IP:", result[0])
        print("Threat Count:", result[1])

    cursor.close()
    connection.close()