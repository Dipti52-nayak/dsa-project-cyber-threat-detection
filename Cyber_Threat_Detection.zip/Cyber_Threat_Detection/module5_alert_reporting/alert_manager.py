class AlertManager:

    def __init__(self):
        self.alerts = []

    def add_alert(self, threat):

        self.alerts.append(threat)

        print("\n================================")
        print("       CYBER SECURITY ALERT")
        print("================================")

        print("Source IP:", threat["source_ip"])
        print("Threat Type:", threat["threat_type"])
        print("Threat Level:", threat["threat_level"])
        print("Priority:", threat["priority"])

        print("================================")

    def display_alerts(self):

        print("\n======= ALL SECURITY ALERTS =======")

        if len(self.alerts) == 0:
            print("No Alerts Available")
            return

        for alert in self.alerts:

            print("--------------------------------")
            print("IP:", alert["source_ip"])
            print("Threat:", alert["threat_type"])
            print("Level:", alert["threat_level"])
            print("Priority:", alert["priority"])