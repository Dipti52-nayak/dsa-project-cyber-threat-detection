
from module1_traffic_monitoring.traffic_monitor import (
    monitor_traffic,
    display_traffic_summary
)

records = monitor_traffic()

display_traffic_summary(records)
