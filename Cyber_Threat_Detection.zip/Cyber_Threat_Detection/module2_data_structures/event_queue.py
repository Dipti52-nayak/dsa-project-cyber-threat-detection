
class EventQueue:

    def __init__(self):
        self.queue = []

    # Add event to queue
    def enqueue(self, event):

        self.queue.append(event)

        print("Event Added:", event["source_ip"])

    # Remove event from queue
    def dequeue(self):

        if len(self.queue) == 0:
            print("Queue is Empty")
            return None

        return self.queue.pop(0)

    # Display all events
    def display(self):

        print("\n===== NETWORK EVENT QUEUE =====")

        for event in self.queue:

            print(event["source_ip"])

    # Check queue size
    def size(self):

        return len(self.queue)
