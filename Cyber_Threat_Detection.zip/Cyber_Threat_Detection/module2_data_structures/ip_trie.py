
class TrieNode:

    def __init__(self):

        self.children = {}

        self.is_end = False


class IPTrie:

    def __init__(self):

        self.root = TrieNode()

    def insert(self, ip):

        node = self.root

        for char in ip:

            if char not in node.children:

                node.children[char] = TrieNode()

            node = node.children[char]

        node.is_end = True

    def search_prefix(self, prefix):

        node = self.root

        for char in prefix:

            if char not in node.children:

                return False

            node = node.children[char]

        return True
