
class NetworkGraph:

    def __init__(self):

        self.graph = {}

    # Add connection between two IP addresses
    def add_connection(self, source_ip, destination_ip):

        if source_ip not in self.graph:

            self.graph[source_ip] = []

        if destination_ip not in self.graph:

            self.graph[destination_ip] = []

        if destination_ip not in self.graph[source_ip]:

            self.graph[source_ip].append(destination_ip)

        if source_ip not in self.graph[destination_ip]:

            self.graph[destination_ip].append(source_ip)

    # Display network connections
    def display(self):

        print("\n===== NETWORK CONNECTION GRAPH =====")

        for ip, connections in self.graph.items():

            print("\nIP Address:", ip)

            print("Connected With:", connections)

    # Search network connections
    def search(self, ip):

        if ip in self.graph:

            return self.graph[ip]

        return None
