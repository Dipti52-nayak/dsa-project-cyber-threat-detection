
class IPHashTable:

    def __init__(self):
        self.table = {}

    def insert(self, ip):

        if ip in self.table:
            self.table[ip] += 1

        else:
            self.table[ip] = 1

    def search(self, ip):

        if ip in self.table:
            return self.table[ip]

        return 0

    def display(self):

        print("\n===== IP HASH TABLE =====")

        for ip, count in self.table.items():

            print("IP Address:", ip)
            print("Occurrences:", count)
            print("------------------------")
