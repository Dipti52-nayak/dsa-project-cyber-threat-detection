
class ThreatPriorityQueue:

    def __init__(self):
        self.heap = []

    def enqueue(self, threat):

        self.heap.append(threat)

        self._heapify_up(len(self.heap) - 1)

    def _heapify_up(self, index):

        while index > 0:

            parent = (index - 1) // 2

            if self.heap[index]["priority"] < self.heap[parent]["priority"]:

                self.heap[index], self.heap[parent] = (
                    self.heap[parent],
                    self.heap[index]
                )

                index = parent

            else:
                break

    def dequeue(self):

        if len(self.heap) == 0:
            return None

        if len(self.heap) == 1:
            return self.heap.pop()

        highest_priority = self.heap[0]

        self.heap[0] = self.heap.pop()

        self._heapify_down(0)

        return highest_priority

    def _heapify_down(self, index):

        size = len(self.heap)

        while True:

            smallest = index

            left = 2 * index + 1
            right = 2 * index + 2

            if left < size and self.heap[left]["priority"] < self.heap[smallest]["priority"]:
                smallest = left

            if right < size and self.heap[right]["priority"] < self.heap[smallest]["priority"]:
                smallest = right

            if smallest != index:

                self.heap[index], self.heap[smallest] = (
                    self.heap[smallest],
                    self.heap[index]
                )

                index = smallest

            else:
                break

    def display(self):

        print("\n===== THREAT PRIORITY QUEUE =====")

        for threat in self.heap:

            print(
                threat["threat_level"],
                "| Priority:",
                threat["priority"],
                "| IP:",
                threat["source_ip"]
            )

