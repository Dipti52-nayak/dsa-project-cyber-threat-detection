
from collections import deque
from datetime import datetime, timedelta


class SlidingWindow:

    def __init__(self, window_seconds=60, threshold=5):

        self.window_seconds = window_seconds

        self.threshold = threshold

        self.events = {}

    def add_event(self, ip):

        current_time = datetime.now()

        if ip not in self.events:

            self.events[ip] = deque()

        self.events[ip].append(current_time)

        self.remove_old_events(ip)

        if len(self.events[ip]) >= self.threshold:

            return True

        return False

    def remove_old_events(self, ip):

        current_time = datetime.now()

        time_limit = current_time - timedelta(
            seconds=self.window_seconds
        )

        while (
            self.events[ip]
            and self.events[ip][0] < time_limit
        ):

            self.events[ip].popleft()

    def get_event_count(self, ip):

        if ip not in self.events:

            return 0

        self.remove_old_events(ip)

        return len(self.events[ip])
