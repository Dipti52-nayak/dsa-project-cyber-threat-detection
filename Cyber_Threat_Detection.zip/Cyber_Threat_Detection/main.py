from module3_threat_detection.threat_analyzer import ThreatAnalyzer

from module4_database.db_operations import insert_threat

from module5_alert_reporting.alert_manager import AlertManager

from module5_alert_reporting.threat_statistics import show_statistics

from module5_alert_reporting.report_generator import generate_report

from module2_data_structures.priority_queue import ThreatPriorityQueue


def main():

    print("\n==========================================")
    print("     REAL-TIME CYBER THREAT DETECTION")
    print("==========================================")

    analyzer = ThreatAnalyzer()
    alert_manager = AlertManager()
    priority_queue = ThreatPriorityQueue()

    print("\nStarting Threat Detection...\n")

    # MODULE 1: Simulated failed login attempts
    print("\n--- FAILED LOGIN DETECTION ---")

    login_ip = "192.168.1.50"

    for i in range(5):

        threat = analyzer.analyze_login(login_ip, "FAILED")

        if threat:
            insert_threat(threat)
            alert_manager.add_alert(threat)
            priority_queue.enqueue(threat)

    # MODULE 3: Port scanning detection
    print("\n--- PORT SCAN DETECTION ---")

    port_ip = "10.0.0.5"

    ports = [21, 22, 80, 443, 3306]

    for port in ports:

        threat = analyzer.analyze_port(port_ip, port)

        if threat:
            insert_threat(threat)
            alert_manager.add_alert(threat)
            priority_queue.enqueue(threat)

    # DISPLAY ALERTS
    alert_manager.display_alerts()

    # DISPLAY PRIORITY QUEUE
    print("\n======= THREAT PRIORITY ORDER =======")

    while True:

        threat = priority_queue.dequeue()

        if threat is None:
            break

        print(
            threat["threat_level"],
            "|",
            threat["threat_type"],
            "|",
            threat["source_ip"]
        )

    # DISPLAY DATABASE STATISTICS
    show_statistics()

    # GENERATE FINAL REPORT
    generate_report()

    print("\n==========================================")
    print("       PROJECT EXECUTION COMPLETED")
    print("==========================================")


if __name__ == "__main__":
    main()