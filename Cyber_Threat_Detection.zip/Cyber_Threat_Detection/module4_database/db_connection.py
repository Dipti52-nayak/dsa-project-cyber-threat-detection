import mysql.connector


def create_connection():

    connection = mysql.connector.connect(
        host="localhost",
        user="root",
        password="Arjun@2609",
        database="cyber_threat_db"
    )

    return connection