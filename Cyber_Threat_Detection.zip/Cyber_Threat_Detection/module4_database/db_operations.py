from module4_database.db_connection import create_connection


def insert_threat(threat):

    connection = create_connection()
    cursor = connection.cursor()

    query = """
    INSERT INTO threat_logs
    (source_ip, threat_type, threat_level, priority)
    VALUES (%s, %s, %s, %s)
    """

    values = (
        threat["source_ip"],
        threat["threat_type"],
        threat["threat_level"],
        threat["priority"]
    )

    cursor.execute(query, values)

    connection.commit()

    print("Threat Saved Successfully!")

    cursor.close()
    connection.close()
def fetch_threats():

    connection = create_connection()
    cursor = connection.cursor()

    query = "SELECT * FROM threat_logs"

    cursor.execute(query)

    records = cursor.fetchall()

    print("\n========== ALL DETECTED THREATS ==========")

    if len(records) == 0:
        print("No Threat Records Found!")

    else:
        for record in records:

            print("----------------------------------")
            print("Threat ID:", record[0])
            print("Source IP:", record[1])
            print("Threat Type:", record[2])
            print("Threat Level:", record[3])
            print("Priority:", record[4])
            print("Detected At:", record[5])

    cursor.close()
    connection.close()