from module4_database.db_connection import create_connection

connection = create_connection()

if connection.is_connected():
    print("MySQL Database Connected Successfully!")

connection.close()
print("Database Connection Closed.")