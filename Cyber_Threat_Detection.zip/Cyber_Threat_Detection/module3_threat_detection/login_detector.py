from module2_data_structures.sliding_window import SlidingWindow


class LoginDetector:

    def __init__(self):
        self.detector = SlidingWindow(
            window_seconds=60,
            threshold=5
        )

    def check_login(self, ip, status):

        if status == "FAILED":

            suspicious = self.detector.add_event(ip)

            if suspicious:
                return {
                    "source_ip": ip,
                    "threat_level": "HIGH",
                    "threat_type": "Multiple Failed Login Attempts",
                    "priority": 2
                }

        return None