from collections import defaultdict, deque
from datetime import datetime, timedelta


class PortScanDetector:

    def __init__(self, window_seconds=60, threshold=5):

        self.window_seconds = window_seconds
        self.threshold = threshold

        self.ip_ports = defaultdict(deque)

    def check_port(self, ip, port):

        current_time = datetime.now()

        if ip not in self.ip_ports:
            self.ip_ports[ip] = deque()

        self.ip_ports[ip].append((port, current_time))

        time_limit = current_time - timedelta(
            seconds=self.window_seconds
        )

        # Remove events older than 60 seconds
        while (
            self.ip_ports[ip]
            and self.ip_ports[ip][0][1] < time_limit
        ):
            self.ip_ports[ip].popleft()

        # Count unique ports
        unique_ports = set()

        for port_number, timestamp in self.ip_ports[ip]:
            unique_ports.add(port_number)

        # Detect port scanning
        if len(unique_ports) >= self.threshold:

            return {
                "source_ip": ip,
                "threat_level": "HIGH",
                "threat_type": "Port Scanning Detected",
                "priority": 2,
                "ports_scanned": len(unique_ports)
            }

        return None