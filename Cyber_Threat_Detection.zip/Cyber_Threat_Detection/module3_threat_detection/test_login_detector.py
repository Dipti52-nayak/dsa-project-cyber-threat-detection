from module3_threat_detection.login_detector import LoginDetector

detector = LoginDetector()

ip = "192.168.1.50"

print("===== LOGIN THREAT DETECTION =====")

for i in range(1, 7):

    result = detector.check_login(ip, "FAILED")

    print("Login Attempt:", i)

    if result:
        print("\n!!! THREAT DETECTED !!!")
        print("Source IP:", result["source_ip"])
        print("Threat Level:", result["threat_level"])
        print("Threat Type:", result["threat_type"])
        print("Priority:", result["priority"])