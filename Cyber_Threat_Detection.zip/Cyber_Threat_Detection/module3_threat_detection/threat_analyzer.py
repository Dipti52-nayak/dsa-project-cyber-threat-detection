from module3_threat_detection.login_detector import LoginDetector
from module3_threat_detection.port_scan_detector import PortScanDetector


class ThreatAnalyzer:

    def __init__(self):
        self.login_detector = LoginDetector()
        self.port_detector = PortScanDetector()
        self.detected_threats = []

    def analyze_login(self, ip, status):

        threat = self.login_detector.check_login(ip, status)

        if threat:
            self.detected_threats.append(threat)
            print("\n[ALERT] Login Threat Detected!")

        return threat

    def analyze_port(self, ip, port):

        threat = self.port_detector.check_port(ip, port)

        if threat:
            self.detected_threats.append(threat)
            print("\n[ALERT] Port Scanning Detected!")

        return threat

    def display_threats(self):

        print("\n===== DETECTED THREATS =====")

        for threat in self.detected_threats:
            print(threat)