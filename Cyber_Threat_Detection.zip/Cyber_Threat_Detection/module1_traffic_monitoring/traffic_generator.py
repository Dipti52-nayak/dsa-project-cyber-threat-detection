
import random
from datetime import datetime


def generate_traffic():

    source_ips = [
        "192.168.1.10",
        "192.168.1.20",
        "192.168.1.30",
        "10.0.0.5",
        "172.16.0.8"
    ]

    destination_ips = [
        "192.168.1.100",
        "192.168.1.200",
        "10.0.0.10"
    ]

    ports = [80, 443, 22, 21, 3306, 8080]

    protocols = ["TCP", "UDP"]

    traffic = {
        "source_ip": random.choice(source_ips),
        "destination_ip": random.choice(destination_ips),
        "source_port": random.randint(1024, 65535),
        "destination_port": random.choice(ports),
        "protocol": random.choice(protocols),
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    }

    return traffic
