
import time

from module1_traffic_monitoring.traffic_generator import generate_traffic


def monitor_traffic():

    traffic_records = []

    print("\n====================================")
    print("     NETWORK TRAFFIC MONITOR")
    print("====================================")

    print("\nMonitoring Started...\n")

    for i in range(5):

        traffic = generate_traffic()

        traffic_records.append(traffic)

        print(f"Traffic Event: {i + 1}")
        print("------------------------------------")

        print("Source IP:", traffic["source_ip"])
        print("Destination IP:", traffic["destination_ip"])
        print("Source Port:", traffic["source_port"])
        print("Destination Port:", traffic["destination_port"])
        print("Protocol:", traffic["protocol"])
        print("Timestamp:", traffic["timestamp"])

        print("------------------------------------\n")

        time.sleep(1)

    print("Monitoring Completed!")

    print("\nTotal Traffic Events:", len(traffic_records))

    return traffic_records

def display_traffic_summary(records):

    print("\n========== TRAFFIC SUMMARY ==========")

    total_events = len(records)

    unique_ips = set()

    for record in records:
        unique_ips.add(record["source_ip"])

    print("Total Traffic Events:", total_events)

    print("Unique Source IPs:", len(unique_ips))

    print("\nSource IP Addresses:")

    for ip in unique_ips:
        print(ip)

    print("=====================================")
